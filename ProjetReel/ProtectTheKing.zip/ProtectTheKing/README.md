# Projet Dev jeux vidéos
## Protect the king

### To Do

-obligatoire
* plateau
* tours
* ennemis
* atouts (boule de feu, electricité, gel, tempete)
* système de monnaie
* partie infinie

-optionel

* mini mode histoire
* choisir difficulté (nombre de vie, nombre de vagues, nombre d'ennemis et ect) ou soit un mode avec des vagues à l'infini 
* musique 
* gérer les niveaux du joueur (XP, boost XP, récompense[sorts?])
* 10 niveaux
* animation du roi lorsqu'il est attaqué 

## Collaborateurs

#### * Adamaheto Saviour

#### * Noel Alexandre

#### * Dorchy Lucas

#### * Shaw Axel 

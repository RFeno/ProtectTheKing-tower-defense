#include "vMainMenu.h"
#include <SFML/Graphics.hpp>

using namespace sf;

vMainMenu::vMainMenu()
{
    //ctor
}

vMainMenu::~vMainMenu()
{
    //dtor
}

void vMainMenu::launchMenu()
{
    //size of screen fix
    sf::RenderWindow window(VideoMode(WIN_WIDTH, WIN_HEIGHT), "Protect the tower - Welcome");

    //vsynch activation
    window.setVerticalSyncEnabled(true);

    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            //close if he click
            if (event.type == Event::Closed)
                window.close();
        }

        window.clear();
        window.display();
    }
}

void vMainMenu::loadFont()
{
    Font font;

    if(!font.loadFromFile("res/fonts/plump.tff"))
    {
        cout << "error to charge font " << endl;
    }
}

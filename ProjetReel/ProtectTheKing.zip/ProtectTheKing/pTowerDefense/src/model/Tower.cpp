#include "Tower.h"
#include <Enemies.h>
#include <stdexcept>
using namespace std;

Tower::Tower(int damage, int level, int price): damage(damage), level(level), price(price)
{
    //ctor
    if(level<=0)
    {
        throw runtime_error("The level of tower cannot be below one");
    }
}

Tower::~Tower()
{
    //dtor
}

Tower::Tower(const Tower& other)
{
    //copy ctor
}

/*Tower& Tower::operator=(const Tower& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}*/

void Tower::attackEnemy(Enemies& cible)const
{
    cible.receiveDamage(damage);
}

bool Tower::improveLevel()
{
    if(level+1 <= 3)
    {
        level++;
        return true;
    }
    return false;
}

string Tower::toString()const
{
    return "[Tower: damage=> " + to_string(damage) + " level=>" + to_string(level) + " price=>"+ to_string(price) + "]";
}

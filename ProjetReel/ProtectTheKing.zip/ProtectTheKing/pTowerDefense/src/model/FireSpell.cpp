#include "FireSpell.h"

FireSpell::FireSpell()
{
    //ctor
}

FireSpell::~FireSpell()
{
    //dtor
}

/*FireSpell::FireSpell(const FireSpell& other)
{
    //copy ctor
}

FireSpell& FireSpell::operator=(const FireSpell& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}*/

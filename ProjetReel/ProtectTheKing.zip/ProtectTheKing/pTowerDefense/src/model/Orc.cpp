#include "Orc.h"

Orc::Orc()
{
    //ctor
}

Orc::~Orc()
{
    //dtor
}

Orc::Orc(const Orc& other)
{
    //copy ctor
}

Orc& Orc::operator=(const Orc& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

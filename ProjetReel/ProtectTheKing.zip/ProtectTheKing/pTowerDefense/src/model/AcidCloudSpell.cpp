#include "AcidCloudSpell.h"

AcidCloudSpell::AcidCloudSpell()
{
    //ctor
}

AcidCloudSpell::~AcidCloudSpell()
{
    //dtor
}

AcidCloudSpell::AcidCloudSpell(const AcidCloudSpell& other)
{
    //copy ctor
}

AcidCloudSpell& AcidCloudSpell::operator=(const AcidCloudSpell& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

#ifndef VMAINMENU_H
#define VMAINMENU_H


class vMainMenu
{
    public:
        vMainMenu();
        void launchMenu();
        void loadFont();
        virtual ~vMainMenu();
        const int WIN_WIDTH = 1366;
        const int WIN_HEIGHT = 800;

    protected:

    private:

};

#endif // VMAINMENU_H

#ifndef GAME_H
#define GAME_H


class Game
{
    public:
        Game();
        virtual ~Game();
        Game(const Game& other);
        Game& operator=(const Game& other);

    protected:

    private:
};

#endif // GAME_H

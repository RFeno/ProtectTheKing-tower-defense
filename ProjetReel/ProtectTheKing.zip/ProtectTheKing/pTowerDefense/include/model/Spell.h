#ifndef SPELL_H
#define SPELL_H


class Spell
{
    public:
        Spell();
        virtual ~Spell();
        Spell(const Spell& other);
        Spell& operator=(const Spell& other);

    protected:

    private:
};

#endif // SPELL_H

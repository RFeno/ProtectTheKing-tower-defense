#ifndef KING_H
#define KING_H


class King
{
    public:
        King();
        virtual ~King();
        King(const King& other);
        King& operator=(const King& other);

    protected:

    private:
};

#endif // KING_H

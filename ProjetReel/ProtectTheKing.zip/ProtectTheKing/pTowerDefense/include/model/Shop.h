#ifndef SHOP_H
#define SHOP_H


class Shop
{
    public:
        Shop();
        virtual ~Shop();

    protected:

    private:
};

#endif // SHOP_H

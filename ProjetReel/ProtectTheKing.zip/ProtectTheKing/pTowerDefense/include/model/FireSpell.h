#ifndef FIRESPELL_H
#define FIRESPELL_H


class FireSpell
{
    public:
        FireSpell();
        virtual ~FireSpell();

    protected:

    private:
};

#endif // FIRESPELL_H
